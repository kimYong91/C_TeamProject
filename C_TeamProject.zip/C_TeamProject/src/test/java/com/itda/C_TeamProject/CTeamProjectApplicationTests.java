package com.itda.C_TeamProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CTeamProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
